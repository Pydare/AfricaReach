class PlanetInfo {
  final int position;
  final String iconImage;
  final String description;
  final String company_name;
  final String city;
  final String geo;
  final String job_board;
  final String requirement;
  final String job_title;
  final String job_type;
  final String post_date;
  final String salary_offer;
  final String state;
  final String catagory;
  final List<String> images;

  PlanetInfo(
      this.position, {
        required this.iconImage,
        required this.description,
        required this.images,
        required this.company_name,
        required this.city,
        required this.geo,
        required this.job_board,
        required this.requirement,
        required this.job_title,
        required this.job_type,
        required this.post_date,
        required this.salary_offer,
        required this.state,
        required this.catagory,
      });
}

List<PlanetInfo> planets = [
  PlanetInfo(1,
      company_name: 'Talent Point Ltd ',
      iconImage: 'assets/mercury.png',
      description:
        "Apply now QA Engineer, Test Engineer, Java, API, Rest-assured, Postman, microservices, Selenium Â£400-Â£500 Leeds 6 month on-rolling Contract ",
      city: "Wimbledon",
      geo: "UK",
      job_board: "reed",
      requirement: "dfgdf",
      job_title: "Communications Officer",
      job_type: "full-time",
      salary_offer: " £11.32 - £14.70 per hour ",
      state: "Devon",
      catagory: "marketing jobs",
      images: [],
      post_date: "Oct 21, 2021",
  ),
  PlanetInfo(1,
    company_name: 'Talent Point Ltd ',
    iconImage: 'assets/mercury.png',
    description:
    "Apply now QA Engineer, Test Engineer, Java, API, Rest-assured, Postman, microservices, Selenium Â£400-Â£500 Leeds 6 month on-rolling Contract ",
    city: "Wimbledon",
    geo: "UK",
    job_board: "reed",
    requirement: "dfgdf",
    job_title: "Communications Officer",
    job_type: "full-time",
    salary_offer: " £11.32 - £14.70 per hour ",
    state: "Devon",
    catagory: "marketing jobs",
    images: [],
    post_date: "Oct 21, 2021",
  ),PlanetInfo(1,
    company_name: 'Talent Point Ltd ',
    iconImage: 'assets/mercury.png',
    description:
    "Apply now QA Engineer, Test Engineer, Java, API, Rest-assured, Postman, microservices, Selenium Â£400-Â£500 Leeds 6 month on-rolling Contract ",
    city: "Wimbledon",
    geo: "UK",
    job_board: "reed",
    requirement: "dfgdf",
    job_title: "Communications Officer",
    job_type: "full-time",
    salary_offer: " £11.32 - £14.70 per hour ",
    state: "Devon",
    catagory: "marketing jobs",
    images: [],
    post_date: "Oct 21, 2021",
  ),PlanetInfo(1,
    company_name: 'Talent Point Ltd ',
    iconImage: 'assets/mercury.png',
    description:
    "Apply now QA Engineer, Test Engineer, Java, API, Rest-assured, Postman, microservices, Selenium Â£400-Â£500 Leeds 6 month on-rolling Contract ",
    city: "Wimbledon",
    geo: "UK",
    job_board: "reed",
    requirement: "dfgdf",
    job_title: "Communications Officer",
    job_type: "full-time",
    salary_offer: " £11.32 - £14.70 per hour ",
    state: "Devon",
    catagory: "marketing jobs",
    images: [],
    post_date: "Oct 21, 2021",
  ),


];
