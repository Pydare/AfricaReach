package com.example.jobmatch

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
